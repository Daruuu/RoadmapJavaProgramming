package examenpoo.problema02;

public interface Venda {
    void realitzaVenda();

}
